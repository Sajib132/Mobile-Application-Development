package com.example.mobilediagonstictool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import static java.lang.System.getProperty;

public class Display extends AppCompatActivity {
    TextView textView;
    Build build;
    Build.VERSION version;
    String device_info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        textView = findViewById(R.id.textView);
        display_info();
        textView.setText(device_info);
    }

    private void display_info() {
        device_info =
                "Display : " + build.DISPLAY + "\n\n" +
                "Fingerprint : " + build.FINGERPRINT + "\n\n" +
                "Host : " + build.HOST + "\n\n" ;



    }
}