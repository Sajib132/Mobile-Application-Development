package com.example.mobilediagonstictool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    CardView display, hardware, camera, sound, network, ram,
            sensor, battery, gps, info,cpu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display =(CardView) findViewById(R.id.c1);
        hardware = (CardView) findViewById(R.id.c2);
        camera = (CardView) findViewById(R.id.c4);
        sound = (CardView) findViewById(R.id.c6);
        network = (CardView) findViewById(R.id.c7);
        ram = (CardView) findViewById(R.id.c5);
        sensor = (CardView) findViewById(R.id.c8);
        battery = (CardView) findViewById(R.id.c3);
        gps = (CardView) findViewById(R.id.c9);
        info = (CardView) findViewById(R.id.c10);
        cpu = (CardView) findViewById(R.id.c11);





        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDisplay();
            }
        });
        hardware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHardware();
            }
        });
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCamera();
            }
        });
        sensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
        ram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openRam();
            }
        });
       network.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNetwork();
            }
        });
       battery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBattery();
            }
        });
        cpu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                opencpu();
            }
        });
        gps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });
       info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openAnother_Activity();
            }
        });






    }

    private void openAnother_Activity() {
        Intent intent = new Intent(this,Another_Activity.class);
        startActivity(intent);
    }
    private void openHardware() {
        Intent intent = new Intent(this, Hardware.class);
        startActivity(intent);
    }
    private void openBattery() {
        Intent intent = new Intent(this, Battery.class);
        startActivity(intent);
    }
    private void openCamera() {
        Intent intent = new Intent(this, Camera.class);
        startActivity(intent);
    }
    private void openRam() {
        Intent intent = new Intent(this, Ram.class);
        startActivity(intent);
    }
    private void opencpu() {
        Intent intent = new Intent(this, CPU.class);
        startActivity(intent);
    }
    private void openDisplay() {
        Intent intent = new Intent(this, Display.class);
        startActivity(intent);
    }
    private void openNetwork() {
        Intent intent = new Intent(this, Network.class);
        startActivity(intent);
    }
//    private void opengps() {
//        Intent intent = new Intent(this, GPS.class);
//        startActivity(intent);
//    }

}