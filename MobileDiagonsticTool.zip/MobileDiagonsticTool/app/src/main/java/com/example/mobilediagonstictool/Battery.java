package com.example.mobilediagonstictool;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class Battery extends AppCompatActivity {
    private TextView batteryLevel, bh, status, charging;
    private ProgressBar progressBar;
    BroadcastReceiver batteryBroadcast;   // broad cast reciver for the battery %


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battery);

        batteryLevel = findViewById(R.id.batterylevel);
        bh = findViewById(R.id.batteryhealth);
        status = findViewById(R.id.status);
        charging = findViewById(R.id.charging);
       progressBar = findViewById(R.id.progressBar);


        batteryBroadcast = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); // variable for battery level
                int health1 = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);//Variable for health
                int charger = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED,0); //variable for charging type
                int batstatus =intent.getIntExtra(BatteryManager.EXTRA_STATUS,0);  // variable for status
                batteryLevel.setText(String.valueOf(level) + "%");   // this line will print out the battery level along with %

                // This will check the condition on batteryhealth and return the value to variable and print on assigned text value
                switch (health1) {
                    case BatteryManager.BATTERY_HEALTH_GOOD:
                        bh.setText("Good");
                        break;
                    case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                        bh.setText("Unknown");
                        break;
                    case BatteryManager.BATTERY_HEALTH_DEAD:
                        bh.setText("Dead");
                        break;
                    case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                        bh.setText("Failed");
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                        bh.setText("OverVoltage");
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                        bh.setText("OverHeat");
                        break;
                }
                // code for how we are charging the phone
                switch (charger){
                    case BatteryManager.BATTERY_PLUGGED_AC:
                        charging.setText("Via AC");
                        break;
                    case BatteryManager.BATTERY_PLUGGED_USB:
                        charging.setText("Via USB/DC");
                        break;
                    case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                        charging.setText("Via Wireless");
                        break;
                    default:
                        charging.setText("None");

                }
                // code to find out status of battery
                switch(batstatus){
                    case BatteryManager.BATTERY_STATUS_CHARGING:
                        status.setText("Charging");
                        break;
                    case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                        status.setText("Not-Charging");
                        break;
                    case BatteryManager.BATTERY_STATUS_FULL:
                        status.setText("Battery Full");
                        break;
                    case BatteryManager.BATTERY_STATUS_DISCHARGING:
                        status.setText("Battery Discharging");
                        break;
                    default:
                        status.setText("Unknown");

                }
               // progressBar.setProgress(30);

            }
        };
        // this line of code is going to register the broadcastreciever
        this.registerReceiver(this.batteryBroadcast, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        // no need to declare intent filter because "new IntentFilter(Intent.ACTION_BATTERY_CHANGED)" it already did


    }
}




//public class Battery extends AppCompatActivity {
//
//    private TextView batterLevel;
//
//    public void onCreate(Bundle icicle) {
//        super.onCreate(icicle);
//        setContentView(R.layout.activity_battery);
//        batterLevel = (TextView) this.findViewById(R.id.batteryLevel);
//        batteryLevel();
//    }
//    batteryBroadcast = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0); // variable for battery level
//            int health1 = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);//Variable for health
//            int charger = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED,0); //variable for charging type
//            int batstatus =intent.getIntExtra(BatteryManager.EXTRA_STATUS,0);  // variable for status
//            batterylevel.setText(String.valueOf(level) + "%");
//
//
//    private void batteryLevel() {
//        BroadcastReceiver batteryLevelReceiver = new BroadcastReceiver() {
//            public void onReceive(Context context, Intent intent) {
//                context.unregisterReceiver(this);
//                int rawlevel = intent.getIntExtra("level", -1);
//                int scale = intent.getIntExtra("scale", -1);
//                int level = -1;
//                if (rawlevel >= 0 && scale > 0) {
//                    level = (rawlevel * 100) / scale;
//                }
//                batterLevel.setText("Battery Level Remaining: " + level + "%");
//            }
//        };
//        IntentFilter batteryLevelFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
//        registerReceiver(batteryLevelReceiver, batteryLevelFilter);
//    }





