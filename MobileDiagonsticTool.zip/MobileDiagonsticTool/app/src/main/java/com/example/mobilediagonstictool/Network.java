package com.example.mobilediagonstictool;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Build;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.CellSignalStrengthGsm;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

import static android.telephony.TelephonyManager.NETWORK_TYPE_EDGE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GPRS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_GSM;
import static android.telephony.TelephonyManager.NETWORK_TYPE_HSDPA;
import static android.telephony.TelephonyManager.NETWORK_TYPE_LTE;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UMTS;
import static android.telephony.TelephonyManager.NETWORK_TYPE_UNKNOWN;

public class Network extends AppCompatActivity {

    private TextView networkstats, str, sn;
    private TelephonyManager telephonyManager, TM;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network);

        networkstats = findViewById(R.id.networkstats);
        str = findViewById(R.id.str);
        sn = findViewById(R.id.signal);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, PackageManager.PERMISSION_GRANTED);

        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (ActivityCompat.checkSelfPermission(Network.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        switch (telephonyManager.getDataNetworkType()) {
                            case NETWORK_TYPE_EDGE:
                                networkstats.setText("Edge");
                                break;
                            case NETWORK_TYPE_GSM:
                                networkstats.setText("Edge");
                                break;
                            case NETWORK_TYPE_GPRS:
                                networkstats.setText("GPRS");
                                break;
                            case NETWORK_TYPE_UMTS:
                                networkstats.setText("UMTS");
                                break;
                            case NETWORK_TYPE_HSDPA:
                                networkstats.setText("HSDPA");
                                break;
                            case NETWORK_TYPE_LTE:
                                networkstats.setText("LTE");
                                break;
                            case NETWORK_TYPE_UNKNOWN:
                                networkstats.setText("Unknown");
                                break;
                            default:
                                networkstats.setText("4G");
                                break;

                        }
                        boolean roaming = telephonyManager.isNetworkRoaming();
                        String DataStatus;
                        if (roaming) {
                            DataStatus = "Roaming";
                        } else {
                            DataStatus = "Searching";
                        }
                        str.setText(DataStatus);


                    }
                });
            }
        }, 0, 500);
    }
}