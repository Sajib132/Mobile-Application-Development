package com.example.mobilediagonstictool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.widget.TextView;

import java.util.List;

import static java.lang.System.getProperty;

public class Hardware extends AppCompatActivity {

    TextView textView,textView1;
    Build build;
    Build.VERSION version;
    String device_info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware);

        textView = findViewById(R.id.textView);
        textView1 = findViewById(R.id.textView1);


        hardware_info();
        textView.setText(device_info);
        //getImeiDetails();
//        String simSerialNo = "";
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
//
//            SubscriptionManager subsManager = (SubscriptionManager) getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
//
//            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                // TODO: Consider calling
//                //    ActivityCompat#requestPermissions
//                // here to request the missing permissions, and then overriding
//                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                //                                          int[] grantResults)
//                // to handle the case where the user grants the permission. See the documentation
//                // for ActivityCompat#requestPermissions for more details.
//                return;
//            }
//            List<SubscriptionInfo> subsList = subsManager.getActiveSubscriptionInfoList();
//
//            if (subsList!=null) {
//                for (SubscriptionInfo subsInfo : subsList) {
//                    if
//                    (subsInfo != null) {
//                        simSerialNo  = subsInfo.getIccId();
//                    }
//                }
//            }
//        } else {
//            TelephonyManager tMgr = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
//            simSerialNo = tMgr.getSimSerialNumber();
//        }
//        textView1.setText(simSerialNo);
 }

    
    private void hardware_info() {
        device_info = "Device Name :" +build.DEVICE +"\n\n"+
                "Android Version : "+ Build.VERSION.RELEASE +"\n\n"+
                "Android Id : " + build.ID + "\n\n" +
                "Version SDK : " + version.SDK_INT + "\n\n" +
                "Brand :" + build.BRAND + "\n\n" +

                "Model : " + build.MODEL + "\n\n" +
                "Product : " + build.PRODUCT + "\n\n" +
                "Hardware : " + build.HARDWARE + "\n\n" +
                "Manufacturer : " + build.MANUFACTURER + "\n\n" +
                "Kernel Version : " + getProperty("os.version") + " ," +getProperty("os.name") +" ,"+getProperty("os.arch")+ "\n\n" +
                "Security : " + version.SECURITY_PATCH + "\n\n" +
                "Board : " + build.BOARD + "\n\n" +
                "Boot Loader : " + build.BOOTLOADER + "\n\n" +

                "Serial : " + build.SERIAL + "\n\n"+

                "Type : " + build.TYPE + "\n\n" +
                "USER : " + build.USER;


    }
//    private void getImeiDetails() {
//        TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            textView1.setText("IMEI 1 : " + telephonyManager.getImei(0));
//            textView1.setText("IMEI 2 : " + telephonyManager.getImei(1));
//        } else {
//            System.out.println("()()()() " + telephonyManager.getDeviceId());
//        }
//    }

}