package com.example.mobilediagonstictool;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.widget.TextView;

import java.io.File;

public class Ram extends AppCompatActivity {

    TextView tv1, tv2,tv3,tv4,tv5;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ram);


        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);
        tv3=findViewById(R.id.tv3);
        tv4=findViewById(R.id.tv4);
        tv5=findViewById(R.id.tv5);


        ActivityManager.MemoryInfo m1 = new ActivityManager.MemoryInfo();
        ActivityManager avm = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        avm.getMemoryInfo(m1);

        float av =m1.availMem/(1024*1024);
        float tt =m1.totalMem/(1024*1024);
       float us =(tt-av);

        tv1.setText("Available Ram: "+String.valueOf(av)+ "MB");
        tv2.setText("Total Ram: "+String.valueOf(tt) + "MB");
        tv3.setText("Used Ram: "+String.valueOf(us)+ "MB");

        File path = Environment.getDataDirectory();
        StatFs fs =new StatFs(path.getPath());
        long block = fs.getBlockSizeLong();
        long avl = fs.getAvailableBlocksLong()*block/(1024*1024);
        long total = fs.getBlockCountLong()*block/(1024*1024);

        tv4.setText("Available Storage: "+String.valueOf(avl)+"MB");
        tv5.setText("Total Storage: "+String.valueOf(total)+ "MB");







    }
}